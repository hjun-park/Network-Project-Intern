//=============================
// arp.h
//=============================

//=============================
// 1 : Ethernet 헤더
//=============================


//=============================
// 2 : ARP 헤더
//=============================
typedef struct _arp_header {
	u_int16_t hw_type;
	u_int16_t protocol_type;
	u_char hw_len;
	u_char protocol_len;
	u_int16_t opcode;
	u_char src_mac[6];
	u_char src_ip[4];
	u_char dst_mac[6];
	u_char dst_ip[4];
} arp_header;


//=============================
// 3 : arp 관련 함수들
//=============================
