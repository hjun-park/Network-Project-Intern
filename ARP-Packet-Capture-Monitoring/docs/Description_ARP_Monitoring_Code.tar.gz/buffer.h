//=============================
// buffer.h
//=============================

//=============================
// Queue 전처리문
//=============================
#ifndef __circle_queue_H__
#define __circle_queue_H__

#define TRUE	1
#define FALSE	0
#define ERROR	-1
#define MAX_SIZE	100

typedef int element;

//=============================
// Queue Node
//  1. rear / front / data(struct)
//=============================
typedef struct _CircleQueue {
	int rear;
	int front;
	element *data;
} Queue;


//=============================
//  나머지 함수 입력 
//=============================

void Enqueue(Node);
Node Dequeue();
void CleanUp();
void IsEemptyCheck();
void IsFullCheck();


#endif
