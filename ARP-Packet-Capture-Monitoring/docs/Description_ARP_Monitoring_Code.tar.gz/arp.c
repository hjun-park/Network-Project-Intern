//=============================
// arp.c
//=============================
#include "arp.h"
#include "buffer.h"

//=============================
// ARP 패킷 캡처 설정 & 실행
//  1. sniffer 생성
//  2. sniffer 필더 설정
//  3. sniffer 실행
//  3-1. arp_parser() 함수 호출 - 파싱
//=============================

//=============================
// ARP 패킷 캡처 시 실행할 callback
//  1. ARP offset 계산 arp 부분 출력
//   1) ARP 타입(Request, Reply, GARP)
//   2) 송신 IP == 수신 IP then GARP 
//   3) 송신 MAC
//   4) 수신 MAC
//	 5) 송신 IP
//   6) 수신 IP
//   7) TimeStamp
//
//  2. buffer에 저장[매핑]
//=============================

